/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.com.chipstore.classes;

/**
 *
 * @author Samuel
 */
// Exemplo de classe Fornecedor

import java.util.ArrayList;
import java.util.List;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class fornecedor {
    // Atributos
    private String nome;
    private String endereco;
    private String telefone;
    private double saldoDevedor;
    private List<pedido> pedidosRecebidos;
    private List<entrega> entregasRealizadas;
    private Map<produto, Integer> estoque;

    // Construtor
    public fornecedor(String nome, String endereco, String telefone, double saldoDevedor) {
        this.nome = nome;
        this.endereco = endereco;
        this.telefone = telefone;
        this.saldoDevedor = saldoDevedor;
        this.pedidosRecebidos = new ArrayList<>();
        this.entregasRealizadas = new ArrayList<>();
        this.estoque = new HashMap<>();
    }

    // Métodos getters e setters (como antes)

    public List<pedido> getPedidosRecebidos() {
        return pedidosRecebidos;
    }

    public List<entrega> getEntregasRealizadas() {
        return entregasRealizadas;
    }

    public double getSaldoDevedor() {
        return saldoDevedor;
    }

    public Map<produto, Integer> getEstoque() {
        return estoque;
    }

    // Método para adicionar um produto ao estoque
    public void adicionarProdutoEstoque(produto produto, int quantidade) {
        if (estoque.containsKey(produto)) {
            int estoqueAtual = estoque.get(produto);
            estoque.put(produto, estoqueAtual + quantidade);
        } else {
            estoque.put(produto, quantidade);
        }
    }

    // Método para remover um produto do estoque
    public boolean removerProdutoEstoque(produto produto, int quantidade) {
        if (estoque.containsKey(produto)) {
            int estoqueAtual = estoque.get(produto);
            if (estoqueAtual >= quantidade) {
                estoque.put(produto, estoqueAtual - quantidade);
                return true;
            } else {
                System.out.println("Estoque insuficiente para remover a quantidade desejada.");
                return false;
            }
        } else {
            System.out.println("Produto não encontrado no estoque.");
            return false;
        }
    }

    // Método para verificar se há estoque suficiente para uma quantidade específica de um produto
    public boolean verificarEstoqueSuficiente(produto produto, int quantidade) {
        if (estoque.containsKey(produto)) {
            int estoqueAtual = estoque.get(produto);
            return estoqueAtual >= quantidade;
        }
        return false;
    }

    // Método para receber um pedido de um cliente
    public void receberPedido(pedido pedido) {
        pedidosRecebidos.add(pedido);
        // Atualizar o saldo devedor do fornecedor com o valor do pedido
        saldoDevedor += pedido.getValorTotal();
    }

    // Método para realizar uma entrega associada a um pedido
    public void realizarEntrega(pedido pedido, entrega entrega) {
        // Verificar se o pedido está na lista de pedidos recebidos
        if (pedidosRecebidos.contains(pedido)) {
            entregasRealizadas.add(entrega);
            pedidosRecebidos.remove(pedido);

            // Atualizar o estoque após realizar a entrega
            for (itemPedido item : pedido.getItens()) {
                produto produto = item.getProduto();
                int quantidade = item.getQuantidade();
                removerProdutoEstoque(produto, quantidade);
            }
        } else {
            System.out.println("Pedido não encontrado para realizar a entrega.");
        }
    }

    // Outros métodos específicos de um fornecedor, conforme necessário

    @Override
    public String toString() {
        return "Fornecedor{" +
                "nome='" + nome + '\'' +
                ", endereco='" + endereco + '\'' +
                ", telefone='" + telefone + '\'' +
                ", saldoDevedor=" + saldoDevedor +
                ", pedidosRecebidos=" + pedidosRecebidos +
                ", entregasRealizadas=" + entregasRealizadas +
                ", estoque=" + estoque +
                '}';
    }

    String getNome() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}

