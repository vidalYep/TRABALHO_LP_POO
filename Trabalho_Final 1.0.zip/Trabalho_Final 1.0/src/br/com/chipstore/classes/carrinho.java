/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.com.chipstore.classes;

/**
 *
 * @author Samuel
 */
public class carrinho {
    // Atributos
    private produto produto;
    private int quantidade;
    private fornecedor fornecedor;

    // Construtor
    public carrinho(produto produto, int quantidade, fornecedor fornecedor) {
        this.produto = produto;
        this.quantidade = quantidade;
        this.fornecedor = fornecedor;
    }

    // Métodos getters e setters
    public produto getProduto() {
        return produto;
    }

    public void setProduto(produto produto) {
        this.produto = produto;
    }

    public int getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(int quantidade) {
        this.quantidade = quantidade;
    }

    public fornecedor getFornecedor() {
        return fornecedor;
    }

    public void setFornecedor(fornecedor fornecedor) {
        this.fornecedor = fornecedor;
    }

    @Override
    public String toString() {
        return "ItemCarrinho{" +
                "produto=" + produto +
                ", quantidade=" + quantidade +
                ", fornecedor=" + fornecedor.getNome() +
                '}';
    }
}


