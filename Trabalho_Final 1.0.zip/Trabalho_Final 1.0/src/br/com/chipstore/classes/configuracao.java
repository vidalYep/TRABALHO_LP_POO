/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.com.chipstore.classes;

/**
 *
 * @author Samuel
 */
public class configuracao {
    // Exemplo de atributos de configuração
    private static double taxaImposto = 0.08; 
    private static String politicaDeEntrega = "Entrega padrão em até 5 dias úteis";

    // Métodos getters e setters para os atributos de configuração

    public static double getTaxaImposto() {
        return taxaImposto;
    }

    public static void setTaxaImposto(double taxaImposto) {
        configuracao.taxaImposto = taxaImposto;
    }

    public static String getPoliticaDeEntrega() {
        return politicaDeEntrega;
    }

    public static void setPoliticaDeEntrega(String politicaDeEntrega) {
        configuracao.politicaDeEntrega = politicaDeEntrega;
    }
}

