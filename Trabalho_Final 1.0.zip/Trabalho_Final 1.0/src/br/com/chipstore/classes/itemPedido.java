/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.com.chipstore.classes;

/**
 *
 * @author Samuel
 */
public class itemPedido {
    // Atributos
    private produto produto;
    private int quantidade;

    // Construtor
    public itemPedido(produto produto, int quantidade) {
        this.produto = produto;
        this.quantidade = quantidade;
    }

    // Métodos getters e setters
    public produto getProduto() {
        return produto;
    }

    public int getQuantidade() {
        return quantidade;
    }

    @Override
    public String toString() {
        return "ItemPedido{" +
                "produto=" + produto +
                ", quantidade=" + quantidade +
                '}';
    }
}
