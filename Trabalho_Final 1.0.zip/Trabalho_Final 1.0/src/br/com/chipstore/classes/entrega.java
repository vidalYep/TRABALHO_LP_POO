/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.com.chipstore.classes;

/**
 *
 * @author Samuel
 */
import java.time.LocalDate;

public class entrega {
    // Atributos
    private LocalDate dataEntrega;
    private String produto;
    private int quantidade;

    // Construtor
    public entrega(LocalDate dataEntrega, String produto, int quantidade) {
        this.dataEntrega = dataEntrega;
        this.produto = produto;
        this.quantidade = quantidade;
    }

    // Métodos getters e setters
    public LocalDate getDataEntrega() {
        return dataEntrega;
    }

    public void setDataEntrega(LocalDate dataEntrega) {
        this.dataEntrega = dataEntrega;
    }

    public String getProduto() {
        return produto;
    }

    public void setProduto(String produto) {
        this.produto = produto;
    }

    public int getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(int quantidade) {
        this.quantidade = quantidade;
    }

    @Override
    public String toString() {
        return "Entrega{" +
                "dataEntrega=" + dataEntrega +
                ", produto='" + produto + '\'' +
                ", quantidade=" + quantidade +
                '}';
    }
}
