/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.com.chipstore.classes;

/**
 *
 * @author Samuel
 */
import java.util.ArrayList;
import java.util.List;

public class pedido {
    // Atributos
    private int numeroPedido;
    private cliente cliente;
    private List<itemPedido> itens;

    // Construtor
    public pedido(int numeroPedido, cliente cliente) {
        this.numeroPedido = numeroPedido;
        this.cliente = cliente;
        this.itens = new ArrayList<>();
    }

    // Métodos getters e setters
    public int getNumeroPedido() {
        return numeroPedido;
    }

    public cliente getCliente() {
        return cliente;
    }

    public List<itemPedido> getItens() {
        return itens;
    }

    // Método para adicionar um item ao pedido
    public void adicionarItem(produto produto, int quantidade) {
        itens.add(new itemPedido(produto, quantidade));
    }

    // Método para calcular o valor total do pedido
    public double getValorTotal() {
        double total = 0;
        for (itemPedido item : itens) {
            total += item.getProduto().getPreco() * item.getQuantidade();
        }
        return total;
    }

    @Override
    public String toString() {
        return "Pedido{" +
                "numeroPedido=" + numeroPedido +
                ", cliente=" + cliente.getNome() +
                ", itens=" + itens +
                '}';
    }
}

