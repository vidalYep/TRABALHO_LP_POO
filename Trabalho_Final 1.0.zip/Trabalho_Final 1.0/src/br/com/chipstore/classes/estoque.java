/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.com.chipstore.classes;

/**
 *
 * @author Samuel
 */
import java.util.HashMap;
import java.util.Map;

public class estoque {
    // Atributos
    private Map<produto, Integer> itensEstoque;

    // Construtor
    public estoque() {
        this.itensEstoque = new HashMap<>();
    }

    // Métodos

    // Adicionar um produto ao estoque com uma quantidade inicial
    public void adicionarProduto(produto produto, int quantidade) {
        if (itensEstoque.containsKey(produto)) {
            int quantidadeAtual = itensEstoque.get(produto);
            itensEstoque.put(produto, quantidadeAtual + quantidade);
        } else {
            itensEstoque.put(produto, quantidade);
        }
    }

    // Remover um produto do estoque com uma quantidade especificada
    public boolean removerProduto(produto produto, int quantidade) {
        if (itensEstoque.containsKey(produto)) {
            int quantidadeAtual = itensEstoque.get(produto);
            if (quantidadeAtual >= quantidade) {
                itensEstoque.put(produto, quantidadeAtual - quantidade);
                return true;
            } else {
                System.out.println("Quantidade insuficiente em estoque para remover.");
                return false;
            }
        } else {
            System.out.println("Produto não encontrado no estoque.");
            return false;
        }
    }

    // Verificar a quantidade disponível de um produto no estoque
    public int verificarQuantidadeDisponivel(produto produto) {
        return itensEstoque.getOrDefault(produto, 0);
    }

    // Verificar se um produto está em estoque
    public boolean verificarProdutoEmEstoque(produto produto) {
        return itensEstoque.containsKey(produto);
    }

    // Obter informações detalhadas do estoque
    public void mostrarEstoque() {
        System.out.println("Estoque:");
        for (Map.Entry<produto, Integer> entry : itensEstoque.entrySet()) {
            produto produto = entry.getKey();
            int quantidade = entry.getValue();
            System.out.println(produto.getNome() + " - Quantidade: " + quantidade);
        }
    }
}

