/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.com.chipstore.dal;

import java.sql.*;

/**
 *
 * @author Samuel
 */
public class ModuloConexao {
    
    // metodo resposvel pela conexao com o banco
   
    public static Connection conector(){
        
        java.sql.Connection conexao = null;
    
        // chamar o drive java/sql
        String driver = "com.mysql.cj.jdbc.Driver";

        // variaveis de conexao com o banco
        String url = "jdbc:mysql://localhost:3306/chipstore";
        String user = "root";
        String password = "";
    
        // valinda e estabelecendo a conexao com o banco
        try {
            Class.forName(driver);
            conexao = DriverManager.getConnection(url, user , password);
            return conexao;
        } catch (Exception e) {
            // para saber qual é o erro:
            // System.out.println(e);
            return null;
        }
    }
}
