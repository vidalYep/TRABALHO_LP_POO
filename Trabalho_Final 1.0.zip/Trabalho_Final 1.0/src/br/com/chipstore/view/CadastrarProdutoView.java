/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JInternalFrame.java to edit this template
 */
package br.com.chipstore.view;

import br.com.chipstore.dal.ModuloConexao;
import java.sql.*;
import javax.swing.JOptionPane;

/**
 *
 * @author Samuel
 */
public class CadastrarProdutoView extends javax.swing.JInternalFrame {

    Connection conexao = null;
    PreparedStatement pst = null;
    ResultSet rs = null;

    private void Consultar() {
        String sql = "select * from produto where codigoprod = ?";

        try {
            pst = conexao.prepareStatement(sql);
            pst.setString(1, TxtCodigo.getText());
            rs = pst.executeQuery();

            if (rs.next()) {
                TxtProduto.setText(rs.getString(2));
                TxtDescricao.setText(rs.getString(3));
                TxtMarca.setText(rs.getString(4));
                TxtQuantidade.setText(rs.getString(5));
                TxtPreco.setText(rs.getString(6));
            } else {
                TxtProduto.setText("");
                TxtDescricao.setText("");
                TxtMarca.setText("");
                TxtQuantidade.setText("");
                TxtPreco.setText("");
                JOptionPane.showMessageDialog(null, "Esse Produto ainda não existe no banco da dados.");
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Erro. Verifique a conexão com o Banco de Dados.");
            System.out.println(e);
        }
    }

    private void Cadastrar() {
        String sql = "insert into produto(codigoprod,nomeprod,descricaoprod,marcaprod,quantidadeprod,precoprod)values(?,?, ?,?,?,?)";

        try {
            pst = conexao.prepareStatement(sql);
            pst.setString(1, TxtCodigo.getText());
            pst.setString(2, TxtProduto.getText());
            pst.setString(3, TxtDescricao.getText());
            pst.setString(4, TxtMarca.getText());
            pst.setString(5, TxtQuantidade.getText());
            pst.setString(6, TxtPreco.getText());

            if ((TxtCodigo.getText().isEmpty()
                    || TxtProduto.getText().isEmpty()
                    || TxtDescricao.getText().isEmpty()
                    || TxtMarca.getText().isEmpty()
                    || TxtQuantidade.getText().isEmpty()
                    || TxtPreco.getText().isEmpty())) {
                JOptionPane.showMessageDialog(null, "Preencha todos os campos!");
            } else {
                // comando responsavel pela inserção dos dados
                int adicionado = pst.executeUpdate();
                // System.out.println(adicionado);
                if (adicionado > 0) {
                    JOptionPane.showMessageDialog(null, "O Produto foi adicionado com sucesso ao banco da dados.");
                    TxtCodigo.setText("");
                    TxtProduto.setText("");
                    TxtDescricao.setText("");
                    TxtMarca.setText("");
                    TxtQuantidade.setText("");
                    TxtPreco.setText("");
                }
            }
            
        } catch (SQLIntegrityConstraintViolationException e) {
            JOptionPane.showMessageDialog(null, "Esse Código ja esta cadastrado. Escolha um diferente.");

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Verifique a conexão com o banco de dados.");
            System.out.println(e);
        }
    }
    
    private void Editar(){
    
        String sql = "update produto set nomeprod = ?, descricaoprod = ?, marcaprod = ?, quantidadeprod = ?, precoprod = ? where codigoprod = ?";
        
        try {
            pst = conexao.prepareStatement(sql);
            
            pst.setString(1, TxtProduto.getText());
            pst.setString(2, TxtDescricao.getText());
            pst.setString(3, TxtMarca.getText());
            pst.setString(4, TxtQuantidade.getText());
            pst.setString(5, TxtPreco.getText());
            pst.setString(6, TxtCodigo.getText());

            if ((TxtCodigo.getText().isEmpty()
                    || TxtProduto.getText().isEmpty()
                    || TxtDescricao.getText().isEmpty()
                    || TxtMarca.getText().isEmpty()
                    || TxtQuantidade.getText().isEmpty()
                    || TxtPreco.getText().isEmpty())) {
                JOptionPane.showMessageDialog(null, "Preencha todos os campos!");
            } else {
                // comando responsavel pela inserção dos dados
                int adicionado = pst.executeUpdate();
                // System.out.println(adicionado);
                if (adicionado > 0) {
                    JOptionPane.showMessageDialog(null, "O Produto foi ALTERADO com sucesso ao banco da dados.");
                    TxtCodigo.setText("");
                    TxtProduto.setText("");
                    TxtDescricao.setText("");
                    TxtMarca.setText("");
                    TxtQuantidade.setText("");
                    TxtPreco.setText("");
                }
            }
            
        } catch (SQLIntegrityConstraintViolationException e) {
            JOptionPane.showMessageDialog(null, "Esse Código ja esta cadastrado. Escolha um diferente.");

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Verifique a conexão com o banco de dados.");
            System.out.println(e);
        }
    }
    
    private void Deletar(){
    
        int confirmar = JOptionPane.showConfirmDialog(null, "Tem certeza que deseja deletar esse produto","ATENÇÃO",JOptionPane.YES_NO_OPTION);
    
        if(confirmar == JOptionPane.YES_OPTION){
        String sql = "delete from produto where codigoprod = ?";
        
            try {
                pst = conexao.prepareStatement(sql);
                pst.setString(1, TxtCodigo.getText());
                
                int adicionado = pst.executeUpdate();
                // System.out.println(adicionado);
                if (adicionado > 0) {
                    JOptionPane.showMessageDialog(null, "O Produto foi DELETADO com sucesso ao banco da dados.");
                    TxtCodigo.setText("");
                    TxtProduto.setText("");
                    TxtDescricao.setText("");
                    TxtMarca.setText("");
                    TxtQuantidade.setText("");
                    TxtPreco.setText("");
                }
                
                
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, "Verifique a conexão com o banco de dados.");
                System.out.println(e);
            }
        }
    }
    
    
    public CadastrarProdutoView() {
        initComponents();
        conexao = ModuloConexao.conector();
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        BtnCadastrar = new javax.swing.JButton();
        BtnConsultar = new javax.swing.JButton();
        BtnEditar = new javax.swing.JButton();
        BtnDeletar = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        TxtCodigo = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        TxtDescricao = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        TxtMarca = new javax.swing.JTextField();
        TxtQuantidade = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        TxtPreco = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        TxtProduto = new javax.swing.JTextField();

        setClosable(true);
        setIconifiable(true);
        setMaximizable(true);
        setResizable(true);
        setTitle("Cadastro de Produtos");
        setDebugGraphicsOptions(javax.swing.DebugGraphics.BUFFERED_OPTION);

        BtnCadastrar.setBackground(new java.awt.Color(102, 255, 102));
        BtnCadastrar.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        BtnCadastrar.setText("Cadastrar");
        BtnCadastrar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        BtnCadastrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnCadastrarActionPerformed(evt);
            }
        });

        BtnConsultar.setBackground(new java.awt.Color(51, 153, 255));
        BtnConsultar.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        BtnConsultar.setText("Consultar");
        BtnConsultar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        BtnConsultar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnConsultarActionPerformed(evt);
            }
        });

        BtnEditar.setBackground(new java.awt.Color(153, 153, 255));
        BtnEditar.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        BtnEditar.setText("Editar");
        BtnEditar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        BtnEditar.setEnabled(false);
        BtnEditar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnEditarActionPerformed(evt);
            }
        });

        BtnDeletar.setBackground(new java.awt.Color(255, 0, 51));
        BtnDeletar.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        BtnDeletar.setText("Deletar");
        BtnDeletar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        BtnDeletar.setEnabled(false);
        BtnDeletar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnDeletarActionPerformed(evt);
            }
        });

        jLabel1.setText("Código:");

        TxtCodigo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TxtCodigoActionPerformed(evt);
            }
        });

        jLabel2.setText("Descrição:");

        jLabel3.setText("Quantidade:");

        jLabel4.setText("Marca:");

        jLabel5.setText("Preço Unitário:");

        jLabel6.setText("Produto:");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(40, 40, 40)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel2)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addComponent(TxtDescricao, javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                            .addComponent(BtnCadastrar)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(BtnConsultar)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(BtnEditar)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(BtnDeletar))
                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(layout.createSequentialGroup()
                                    .addComponent(jLabel5)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addGroup(layout.createSequentialGroup()
                                    .addComponent(TxtPreco)
                                    .addGap(34, 34, 34)))
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                    .addComponent(jLabel3)
                                    .addGap(57, 57, 57))
                                .addComponent(TxtQuantidade, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGroup(layout.createSequentialGroup()
                            .addComponent(jLabel1)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(TxtCodigo, javax.swing.GroupLayout.PREFERRED_SIZE, 204, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(76, 76, 76))
                        .addGroup(layout.createSequentialGroup()
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(layout.createSequentialGroup()
                                    .addComponent(jLabel6)
                                    .addGap(0, 0, Short.MAX_VALUE))
                                .addGroup(layout.createSequentialGroup()
                                    .addComponent(TxtProduto, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                            .addGap(42, 42, 42)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(TxtMarca, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel4)))))
                .addContainerGap(20, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(41, 41, 41)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(TxtCodigo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(26, 26, 26)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(jLabel4))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(TxtMarca, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(TxtProduto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(6, 6, 6)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(TxtDescricao, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(jLabel3))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(TxtPreco, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(TxtQuantidade, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(47, 47, 47)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(BtnCadastrar)
                    .addComponent(BtnConsultar)
                    .addComponent(BtnEditar)
                    .addComponent(BtnDeletar))
                .addContainerGap(29, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void TxtCodigoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TxtCodigoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TxtCodigoActionPerformed

    private void BtnConsultarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnConsultarActionPerformed
        Consultar();
        BtnEditar.setEnabled(true);
        BtnDeletar.setEnabled(true);
    }//GEN-LAST:event_BtnConsultarActionPerformed

    private void BtnCadastrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnCadastrarActionPerformed
        Cadastrar();
    }//GEN-LAST:event_BtnCadastrarActionPerformed

    private void BtnEditarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnEditarActionPerformed
        Editar();
        BtnEditar.setEnabled(false);
        BtnDeletar.setEnabled(false);
    }//GEN-LAST:event_BtnEditarActionPerformed

    private void BtnDeletarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnDeletarActionPerformed
        Deletar();
        BtnEditar.setEnabled(false);
        BtnDeletar.setEnabled(false);
        
    }//GEN-LAST:event_BtnDeletarActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BtnCadastrar;
    private javax.swing.JButton BtnConsultar;
    private javax.swing.JButton BtnDeletar;
    private javax.swing.JButton BtnEditar;
    private javax.swing.JTextField TxtCodigo;
    private javax.swing.JTextField TxtDescricao;
    private javax.swing.JTextField TxtMarca;
    private javax.swing.JTextField TxtPreco;
    private javax.swing.JTextField TxtProduto;
    private javax.swing.JTextField TxtQuantidade;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    // End of variables declaration//GEN-END:variables
}
